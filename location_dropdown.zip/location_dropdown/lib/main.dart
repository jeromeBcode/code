import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class LocationSelector extends StatefulWidget {
  @override
  _LocationSelectorState createState() => _LocationSelectorState();
}

class _LocationSelectorState extends State<LocationSelector> {
  // Variables for form fields
  TextEditingController firstnameController = TextEditingController();
  TextEditingController lastnameController = TextEditingController();
  TextEditingController middlenameController = TextEditingController();
  TextEditingController suffixController = TextEditingController();
  TextEditingController zipCodeController = TextEditingController();

  // Variables for location fields
  String? selectedProvince;
  String? selectedMunicipality;
  String? selectedBarangay;
  bool isLoading = false;
  List<String> provinces = [];
  List<String> municipalities = [];
  List<String> barangays = [];

  @override
  void initState() {
    super.initState();
    fetchProvinces();
  }

  // Fetch provinces from API
  Future<void> fetchProvinces() async {
    setState(() {
      isLoading = true;
    });
    try {
      final response = await http.get(Uri.parse('https://api.example.com/provinces')); // Replace with actual API URL

      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        setState(() {
          provinces = List<String>.from(data.map((province) => province['name']));
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
        throw Exception('Failed to load provinces');
      }
    } catch (error) {
      setState(() {
        isLoading = false;
      });
      print('Error fetching provinces: $error');
    }
  }

  // Fetch municipalities based on selected province
  Future<void> fetchMunicipalities(String province) async {
    setState(() {
      isLoading = true;
    });
    try {
      final response = await http.get(Uri.parse(
          'https://api.example.com/municipalities?province=$province')); // Replace with actual API URL

      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        setState(() {
          municipalities = List<String>.from(data.map((municipality) => municipality['name']));
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
        throw Exception('Failed to load municipalities');
      }
    } catch (error) {
      setState(() {
        isLoading = false;
      });
      print('Error fetching municipalities: $error');
    }
  }

  // Fetch barangays based on selected municipality
  Future<void> fetchBarangays(String municipality) async {
    setState(() {
      isLoading = true;
    });
    try {
      final response = await http.get(Uri.parse(
          'https://api.example.com/barangays?municipality=$municipality')); // Replace with actual API URL

      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        setState(() {
          barangays = List<String>.from(data.map((barangay) => barangay['name']));
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
        throw Exception('Failed to load barangays');
      }
    } catch (error) {
      setState(() {
        isLoading = false;
      });
      print('Error fetching barangays: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Location and Personal Info Selector'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Container at the top for personal information
            Container(
              padding: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.blueGrey.shade50,
                borderRadius: BorderRadius.circular(8),
                boxShadow: [BoxShadow(color: Colors.grey, blurRadius: 5)],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // First Name
                  TextFormField(
                    controller: firstnameController,
                    decoration: InputDecoration(labelText: 'First Name'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'First name is required';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 10),
                  // Last Name
                  TextFormField(
                    controller: lastnameController,
                    decoration: InputDecoration(labelText: 'Last Name'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Last name is required';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 10),
                  // Middle Name
                  TextFormField(
                    controller: middlenameController,
                    decoration: InputDecoration(labelText: 'Middle Name'),
                  ),
                  SizedBox(height: 10),
                  // Suffix
                  TextFormField(
                    controller: suffixController,
                    decoration: InputDecoration(labelText: 'Suffix (e.g., Jr., Sr.)'),
                  ),
                  SizedBox(height: 10),
                ],
              ),
            ),
            SizedBox(height: 20),

            // Province Dropdown
            isLoading
                ? CircularProgressIndicator()
                : DropdownButtonFormField<String>(
                    decoration: InputDecoration(labelText: 'Province'),
                    value: selectedProvince,
                    onChanged: (newValue) {
                      setState(() {
                        selectedProvince = newValue;
                        selectedMunicipality = null; // Reset municipality
                        selectedBarangay = null; // Reset barangay
                      });
                      fetchMunicipalities(newValue!); // Fetch municipalities
                    },
                    items: provinces.map((province) {
                      return DropdownMenuItem<String>(
                        value: province,
                        child: Text(province),
                      );
                    }).toList(),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select a province';
                      }
                      return null;
                    },
                  ),
            SizedBox(height: 20),

            // Municipality Dropdown
            isLoading
                ? CircularProgressIndicator()
                : DropdownButtonFormField<String>(
                    decoration: InputDecoration(labelText: 'Municipality'),
                    value: selectedMunicipality,
                    onChanged: (newValue) {
                      setState(() {
                        selectedMunicipality = newValue;
                        selectedBarangay = null; // Reset barangay
                      });
                      fetchBarangays(newValue!); // Fetch barangays
                    },
                    items: municipalities.map((municipality) {
                      return DropdownMenuItem<String>(
                        value: municipality,
                        child: Text(municipality),
                      );
                    }).toList(),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select a municipality';
                      }
                      return null;
                    },
                  ),
            SizedBox(height: 20),

            // Barangay Dropdown
            isLoading
                ? CircularProgressIndicator()
                : DropdownButtonFormField<String>(
                    decoration: InputDecoration(labelText: 'Barangay'),
                    value: selectedBarangay,
                    onChanged: (newValue) {
                      setState(() {
                        selectedBarangay = newValue;
                      });
                    },
                    items: barangays.map((barangay) {
                      return DropdownMenuItem<String>(
                        value: barangay,
                        child: Text(barangay),
                      );
                    }).toList(),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select a barangay';
                      }
                      return null;
                    },
                  ),
            SizedBox(height: 20),

            // Zip Code Text Field
            TextFormField(
              controller: zipCodeController,
              decoration: InputDecoration(labelText: 'Zip Code'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),

            // Submit Button
            ElevatedButton(
              onPressed: () {
                // Handle form submission (e.g., print values or send to an API)
                print('First Name: ${firstnameController.text}');
                print('Last Name: ${lastnameController.text}');
                print('Middle Name: ${middlenameController.text}');
                print('Suffix: ${suffixController.text}');
                print('Province: $selectedProvince');
                print('Municipality: $selectedMunicipality');
                print('Barangay: $selectedBarangay');
                print('Zip Code: ${zipCodeController.text}');
              },
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}
