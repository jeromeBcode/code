package com.example.location_dropdown

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
